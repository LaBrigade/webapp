/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

// Hide Header on on scroll down
var didScroll;
var lastScrollTop = 0;
var delta = 5;
var navbarHeight = $('#banner').outerHeight();
console.log(navbarHeight);

$(function() {
    $('#main').on('scroll', (function(event){
        didScroll = true;
    }));
});

setInterval(function() {
    if (didScroll) {
        hasScrolled();
        didScroll = false;
    }
}, 250);

function hasScrolled() {
    var st = $('#main').scrollTop();
    console.log(st);
    // Make sure they scroll more than delta
    if(Math.abs(lastScrollTop - st) <= delta)
        return;
    
    // If they scrolled down and are past the navbar, add class .nav-up.
    // This is necessary so you never see what is "behind" the navbar.
    if (st > lastScrollTop && st > navbarHeight){
        // Scroll Down
        $('#banner').removeClass('nav-down').addClass('nav-up');
    } else {
        $('#banner').removeClass('nav-up').addClass('nav-down');
    }
    
    lastScrollTop = st;
}
